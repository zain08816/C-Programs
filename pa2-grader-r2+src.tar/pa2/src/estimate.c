/* PA2 estimate */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	fprintf(stderr, "%s: not implemented\n", argv[0]);
	
	return EXIT_FAILURE;
}
